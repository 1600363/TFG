#pragma once

#include <iostream>
#include <list>
#include <string>
#include <unordered_map>

using namespace std;

class CWifiAccessPoint;

void GuardarEnCSV(const std::list<CWifiAccessPoint>& listaWifis, string aula, const string& filename);

list<CWifiAccessPoint> ObtenerWifis();

list<CWifiAccessPoint> EliminarWifisInnecesarios(list<CWifiAccessPoint> listaWifis);

void RecogerDatos(string nombreFichero);

void CargarDiccionarios(unordered_map<wstring, int>& dict_ssid, unordered_map<wstring, int>& dict_bssid, const wstring& rutaDiccionarioSSID, const wstring& rutaDiccionarioBSSID);

std::wstring DecodificarAula(int64_t valor, const wstring& rutaDiccionarioAulas);

void TransformarValoresWifis(list<CWifiAccessPoint>& listaWifis, const unordered_map<wstring, int>& dict_ssid, const unordered_map<wstring, int>& dict_bssid);

void CrearVectorSSID_BSSID(list<CWifiAccessPoint> listaWifis, vector<float>& intensidadesWifi, const wstring& rutaDiccionarioNombresColumnas);

int64_t CargarRandomForest(vector<float> datosWifi, const wchar_t* rutaRandomForest);

int IdentificarAula(const wstring& rutaDiccionarioSSID, const wstring& rutaDiccionarioBSSID, const wstring& rutaDiccionarioAulas, const wstring& rutaDiccionarioNombresColumnas);