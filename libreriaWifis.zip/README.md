
Esta libreria ofrece funciones útiles para poder obtener la información de las
redes wifi que esten a nuestro alrededor, y poder trabajar con esos datos.

## Requisitos
- ONNX Runtime
- Compilador compatible con C++17

## Instalación
1. Descargar el archivo ZIP y extraer el contenido
2. Agrega el archivo .lib a tu proyecto
3. Agrega el directorio 'include' en la ruta de tu proyecto


## Funciones Disponibles

- list<CWifiAccessPoint> ObtenerWifis():

Esta función escanea los wifis del alrededor y los guarda en una lista de estructura CWifisAccesPoint, que es un
struct con los campos m_SSID, m_BSSID, m_Quality, m_Intensity.


- list<CWifiAccessPoint> EliminarWifisInnecesarios(list<CWifiAccessPoint> listaWifis):

Esta función recibe por parámetro una lista de <CWifiAccessPoint>.
Lo que hace la función es escanear los wifis de esta lista y eliminar aquellos que no correspondan con
los wifis encontrados en la facultad de ingenieria, estos son 'UAB' y 'eduroam'.


- void CargarDiccionarios(unordered_map<wstring, int>& dict_ssid, unordered_map<wstring, int>& dict_bssid, const wstring& rutaDiccionarioSSID, const wstring& rutaDiccionarioBSSID):

Esta función recibe por parámetro dos unordered_map, que tienen que estar vacios y es donde se cargaran los diccionarios, y también dos wstring
que son las rutas a dichos diccionarios.
La función escanea los ficheros indicados y carga su estructura en los dos unordered_map


- void TransformarValoresWifis(list<CWifiAccessPoint>& listaWifis, const unordered_map<wstring, int>& dict_ssid, const unordered_map<wstring, int>& dict_bssid):

Esta función recibe por parámetro la lista de CWifiAccessPoint ya cargada, y dos unordered_map con los diccionarios ssid y bssid ya cargados.
La función recorre la lista de wifis y va codificando sus valores en función de lo indicado en los diccionarios, para que sea mas fácil trabajar con los datos.


- void CrearVectorSSID_BSSID(list<CWifiAccessPoint> listaWifis, vector<float>& intensidadesWifi, const wstring& rutaDiccionarioNombresColumnas):

Esta función recibe por parámetro una lista de CWifiAccessPoint con datos ya cargados, un vector<floats> vacío donde se cargaran los datos y la ruta
al diccionario NombresColumnas.
La función se encarga de cargar en el vector los datos de las intensidades de los wifis, que hay en la lista, en función del orden indicado por el diccionario.
De forma que en el vector quedaran las intensidades en un orden especifico.


- int64_t CargarRandomForest( vector<float> datosWifi, const wchar_t* rutaRandomForest):

Esta función recibe por parámetro un vector con las intensidades wifi cargadas, y la ruta al archivo .onnx que contiene el random forest cargado.
La función carga el random forest y lo configura, para después pasarle como entrada de datos el vector con las intensidades. Como respuesta devuelve un valor
que es el equivalente a la aula predicha.


- wstring DecodificarAula(int64_t valor, const wstring& rutaDiccionarioAulas):

Esta función recibe por parámetro el valor predicho por el random forest y la ruta al diccionario Aulas.
La función desencripta el valor pasado por parámetro para identificar a que aula pertenece, y la devuelve en formato wstring.


- void GuardarEnCSV(const std::list<CWifiAccessPoint>& listaWifis, string aula, const string& filename):

Esta función recibe una lista de CWifiAccesPoint con datos, un nombre de un aula y el nombre donde queremos guardar la información.
La función guarda los datos que hay en la lista en un archivo CSV con el nombre especificado, y a esos datos se le asigna un aula con el nombre indicado por parámetro.


- void RecogerDatos(string nombreFichero):
Esta es una de las dos funciones principales, recibe por parámetro el nombre del archivo donde se quiere guardar la información.
La función va llamando al resto de funciones de la biblioteca, y a partir de algunos datos introducidos por teclado guarda 5 puntos de datos en el fichero especificado.


- int IdentificarAula(const wstring& rutaDiccionarioSSID, const wstring& rutaDiccionarioBSSID, const wstring& rutaDiccionarioAulas, const wstring& rutaDiccionarioNombresColumnas, const wchar_t* rutaRandomForest):
Esta es la función principal de la bilbioteca. Recibe por parámetro la ruta a los 4 diccionarios y la ruta al fichero .onnx con el random forest entrenado.
La función recoge los datos de los wifis del entorno, y llamando al resto de funciones de la biblioteca procesa estos datos, los carga dentro del random forest y devuelve el nombre de la clase donde se ha predicho 
que te encuentras.



## Licencia
Este proyecto esta licenciado bajo los términos de la [MIT License] (./LICENSE)